
async function lookupIP() {
    const ip = document.getElementById("ip").value;
    const errorMessage = document.getElementById("errorMessage");
    errorMessage.textContent = "";
    
    if (!ip) {
        errorMessage.textContent = "Please enter a valid IP address.";
        return;
    }
    
    try {
        const response = await fetch(`https://ipinfo.io/${ip}/json?token=4b708a498f9053`);
        if (!response.ok) throw new Error("Failed to fetch data");
        
        const data = await response.json();
        
        document.getElementById("ipAddress").textContent = data.ip || "N/A";
        document.getElementById("city").textContent = data.city || "N/A";
        document.getElementById("region").textContent = data.region || "N/A";
        document.getElementById("country").textContent = data.country_name || "N/A";
        document.getElementById("isp").textContent = data.org || "N/A";
        document.getElementById("latitude").textContent = data.loc.split(",")[0] || "N/A";
        document.getElementById("longitude").textContent = data.loc.split(",")[1] || "N/A";
        document.getElementById("timezone").textContent = data.timezone || "N/A";
        
        // Embed the map
        const mapsLink = `https://www.embedmymap.com/?gad_source=1&gclid=CjwKCAiAiaC-BhBEEiwAjY99qD4RNVfT3IP-dyKNjxRmUpKXlHWAF_CEC9itnzx-rBayQSd47VJq5BoCVQkQAvD_BwE`;
        document.getElementById("result").classList.remove("hidden");
        document.getElementById("output").innerHTML += `<div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="${mapsLink}"></iframe></div></div>`;
    } catch (error) {
        errorMessage.textContent = "Error fetching IP data. Please try again later.";
    }
}
